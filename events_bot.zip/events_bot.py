"""Standalone Discord bot for the seven supplied event-posting commands."""

from __future__ import annotations

import os
import sqlite3
import time
from contextlib import closing
from dataclasses import dataclass
from pathlib import Path

import discord
from discord.ext import commands
from dotenv import load_dotenv


load_dotenv(Path(__file__).with_name(".env"))
TOKEN = os.getenv("DISCORD_TOKEN", "").strip()
DB_PATH = Path(__file__).with_name("events.sqlite3")
ROBUX_EMOJI = os.getenv("ROBUX_EMOJI", "💰").strip() or "💰"


@dataclass(frozen=True)
class Tier:
    command: str
    title: str
    min_amount: int
    max_amount: int
    default_amount: int
    cooldown: int
    channel_env: str
    role_env: str
    channel_error: str
    cooldown_heading: str
    cooldown_event: str
    stat_key: str
    thread_name: str = ""
    thread_minutes: int = 0
    browse_channels: bool = False


TIERS = {
    "mini": Tier("mini", "Mini", 5, 25, 5, 360, "MINI_CHANNEL_ID", "MINI_ROLE_ID",
                 "Mini Events", "Mini Events", "Mini Event", "mini"),
    "starter": Tier("starter", "Starter", 25, 99, 25, 240, "STARTER_CHANNEL_ID", "STARTER_ROLE_ID",
                    "Starter Events", "Starter Events", "Starter Event", "starter"),
    "rising": Tier("rising", "Rising", 100, 499, 100, 720, "RISING_CHANNEL_ID", "RISING_ROLE_ID",
                   "Rising event", "Rising", "Rising event", "rising", "Rising Event Discussion", 1440),
    "elite": Tier("elite", "Elite", 500, 999, 500, 720, "ELITE_CHANNEL_ID", "ELITE_ROLE_ID",
                  "Elite event", "Elite", "Elite event", "elite", "Elite Event Discussion", 10080),
    "royal": Tier("royal", "Royal", 1000, 4999, 1000, 720, "ROYAL_CHANNEL_ID", "ROYAL_ROLE_ID",
                  "Royal event", "Royal", "Royal event", "royal", "Royal Event Discussion", 10080, True),
    "legendary": Tier("legendary", "Legendary", 5000, 10000, 5000, 720,
                      "LEGENDARY_CHANNEL_ID", "LEGENDARY_ROLE_ID", "Legendary event",
                      "Legendary", "Legendary event", "legendary", "Legendary Event Discussion", 10080),
    "ultimate": Tier("ultimate", "Ultimate", 10000, 2147483647, 10000, 720,
                     "ULTIMATE_CHANNEL_ID", "ULTIMATE_ROLE_ID", "Ultimate event",
                     "Ultimate", "Ultimate event", "ultimate", "Ultimate Event Discussion", 10080),
}


def read_id(name: str) -> int:
    value = os.getenv(name, "").strip()
    return int(value) if value.isdigit() else 0


def open_db() -> sqlite3.Connection:
    return sqlite3.connect(DB_PATH, timeout=10)


def init_db() -> None:
    with closing(open_db()) as db:
        with db:
            db.execute(
                """CREATE TABLE IF NOT EXISTS cooldowns (
                    tier TEXT NOT NULL, user_id INTEGER NOT NULL,
                    last INTEGER NOT NULL, duration INTEGER NOT NULL,
                    PRIMARY KEY (tier, user_id)
                )"""
            )
            db.execute(
                """CREATE TABLE IF NOT EXISTS host_stats (
                    user_id INTEGER PRIMARY KEY,
                    events INTEGER NOT NULL DEFAULT 0,
                    total INTEGER NOT NULL DEFAULT 0,
                    mini INTEGER NOT NULL DEFAULT 0,
                    starter INTEGER NOT NULL DEFAULT 0,
                    rising INTEGER NOT NULL DEFAULT 0,
                    ascendant INTEGER NOT NULL DEFAULT 0,
                    elite INTEGER NOT NULL DEFAULT 0,
                    royal INTEGER NOT NULL DEFAULT 0,
                    legendary INTEGER NOT NULL DEFAULT 0,
                    ultimate INTEGER NOT NULL DEFAULT 0,
                    last INTEGER NOT NULL DEFAULT 0
                )"""
            )


def take_cooldown(tier: Tier, user_id: int, now: int) -> int:
    with closing(open_db()) as db:
        with db:
            row = db.execute(
                "SELECT last, duration FROM cooldowns WHERE tier = ? AND user_id = ?",
                (tier.command, user_id),
            ).fetchone()
            if row:
                remaining = int(row[1]) - (now - int(row[0]))
                if remaining > 0:
                    return remaining
            db.execute(
                """INSERT INTO cooldowns (tier, user_id, last, duration)
                   VALUES (?, ?, ?, ?)
                   ON CONFLICT(tier, user_id) DO UPDATE SET
                     last = excluded.last, duration = excluded.duration""",
                (tier.command, user_id, now, tier.cooldown),
            )
    return 0


def record_host(tier: Tier, user_id: int, amount: int, now: int) -> None:
    # stat_key is defined only in the fixed TIERS table above.
    column = tier.stat_key
    with closing(open_db()) as db:
        with db:
            db.execute("INSERT OR IGNORE INTO host_stats (user_id) VALUES (?)", (user_id,))
            db.execute(
                f"""UPDATE host_stats SET events = events + 1,
                    total = total + ?, {column} = {column} + 1, last = ?
                    WHERE user_id = ?""",
                (amount, now, user_id),
            )


async def post_event(ctx: commands.Context, tier: Tier, amount: int) -> None:
    if not tier.min_amount <= amount <= tier.max_amount:
        await ctx.send(
            f"Usage: -{tier.command} [amount] "
            f"(amount must be {tier.min_amount}–{tier.max_amount})"
        )
        return
    if ctx.guild is None:
        await ctx.send("Use this command in a server channel.")
        return

    channel_id = read_id(tier.channel_env)
    role_id = read_id(tier.role_env)
    if not channel_id or not role_id:
        await ctx.send(
            f"{tier.title} is not configured yet. Set {tier.channel_env} and "
            f"{tier.role_env} in the .env file."
        )
        return
    if ctx.channel.id != channel_id:
        await ctx.send(f"❌ Use this command in the {tier.channel_error} channel.")
        return

    role = ctx.guild.get_role(role_id)
    if role is None:
        await ctx.send(f"The configured {tier.title} event role was not found in this server.")
        return

    now = int(time.time())
    remaining = take_cooldown(tier, ctx.author.id, now)
    if remaining > 0:
        minutes, seconds = divmod(remaining, 60)
        await ctx.send(
            f"⏳ **{tier.cooldown_heading} cooldown active!**\n\n"
            f"Please wait **{minutes}m {seconds}s** before hosting another "
            f"{tier.cooldown_event}."
        )
        return

    robux = discord.utils.get(ctx.guild.emojis, name="robux") or ROBUX_EMOJI
    ping_help = "Want to **change your pings?** Edit them in --> "
    if tier.browse_channels:
        ping_help += "**Browse Channels & Roles** "
    ping_help += "<id:customize>"
    content = (
        f"**{ctx.author.mention} is starting a {tier.title} Event!** "
        f"**({amount} {robux})**\n\n{role.mention}\n\n{ping_help}"
    )
    allowed_mentions = discord.AllowedMentions(
        users=[ctx.author], roles=[role], everyone=False, replied_user=False
    )
    try:
        posted = await ctx.send(content, allowed_mentions=allowed_mentions)
    except discord.Forbidden:
        return

    record_host(tier, ctx.author.id, amount, now)

    if tier.thread_name:
        try:
            await posted.create_thread(
                name=tier.thread_name,
                auto_archive_duration=tier.thread_minutes,
            )
        except discord.Forbidden:
            print(f"Missing permission to create the {tier.title} discussion thread.")
        except discord.HTTPException as error:
            print(f"Could not create the {tier.title} discussion thread: {error}")

    try:
        await posted.add_reaction("👍")
        await posted.add_reaction("👎")
    except discord.Forbidden:
        print(f"Missing permission to add reactions to the {tier.title} event post.")


intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="-", intents=intents)


@bot.command(name="mini")
async def mini(ctx: commands.Context, amount: int = 5) -> None:
    await post_event(ctx, TIERS["mini"], amount)


@bot.command(name="starter")
async def starter(ctx: commands.Context, amount: int = 25) -> None:
    await post_event(ctx, TIERS["starter"], amount)


@bot.command(name="rising")
async def rising(ctx: commands.Context, amount: int = 100) -> None:
    await post_event(ctx, TIERS["rising"], amount)


@bot.command(name="elite")
async def elite(ctx: commands.Context, amount: int = 500) -> None:
    await post_event(ctx, TIERS["elite"], amount)


@bot.command(name="royal")
async def royal(ctx: commands.Context, amount: int = 1000) -> None:
    await post_event(ctx, TIERS["royal"], amount)


@bot.command(name="legendary")
async def legendary(ctx: commands.Context, amount: int = 5000) -> None:
    await post_event(ctx, TIERS["legendary"], amount)


@bot.command(name="ultimate")
async def ultimate(ctx: commands.Context, amount: int = 10000) -> None:
    await post_event(ctx, TIERS["ultimate"], amount)


@bot.event
async def on_command_error(ctx: commands.Context, error: commands.CommandError) -> None:
    error = getattr(error, "original", error)
    if isinstance(error, (commands.BadArgument, commands.TooManyArguments)):
        tier = TIERS.get((ctx.invoked_with or "").lower())
        if tier:
            await ctx.send(
                f"Usage: -{tier.command} [amount] "
                f"(amount must be {tier.min_amount}–{tier.max_amount})"
            )
        return
    if isinstance(error, commands.CommandNotFound):
        return
    print(f"Command error: {error}")


@bot.event
async def on_ready() -> None:
    print(f"Ready as {bot.user} ({bot.user.id})")


if __name__ == "__main__":
    if not TOKEN:
        raise SystemExit("Set DISCORD_TOKEN in the .env file before starting the bot.")
    init_db()
    bot.run(TOKEN)
