# Events bot: event posting commands

This standalone Python bot currently ports the seven event-posting commands:
`-mini`, `-starter`, `-rising`, `-elite`, `-royal`, `-legendary`, and `-ultimate`.
It also includes `-gh @user @hoster-role`, which lets administrators assign one
of the seven configured Hoster roles. The bot needs **Manage Roles**, and its
highest role must be above the Hoster roles. The command reminds the host to read
the rules in channel `1541859515270570117`.

`-gw [amount]` posts a Hosting Giveaway announcement in the channel where it is
used, pings the configured giveaway role, and adds 👍/👎 reactions. The amount is
optional. Set `GIVEAWAY_PING_ROLE_ID` in `.env` to the role ID that should be pinged.

Host management commands are `-hostblacklist @user [reason]`,
`-hostunblacklist @user`, and `-hostblacklistlist`; all require Administrator
permission. A blacklisted user cannot post an event. `-hoststats [@user]` shows
host counts, and `-leaderboard [events|amount]` shows the top ten hosts.

The bot stores cooldowns, host totals, and the host blacklist in a SQLite database.

## Configure

1. Install Python 3.10 or newer.
2. Install the packages in `requirements.txt`.
3. Copy `.env.example` to `.env`. Set the bot token and the new server's channel
   and event-role IDs for every tier you want to use. Set `GIVEAWAY_PING_ROLE_ID`
   to the giveaway notification role. Do not share the token.
4. In the Discord Developer Portal, enable **Message Content Intent**.
5. Add the bot to the server with permission to view and send messages, read
   message history, add reactions, and create public threads in the event channels.
   The event role must be mentionable, or the bot needs permission to mention roles.
6. Run `events_bot.py`. It creates `events.sqlite3` beside the script.

## Railway hosting

For a Railway deployment, upload the bot files without `.env` or `events.sqlite3`.
Set `DATA_DIR=/data` in the service variables, then create a Railway Volume with
mount path `/data` so cooldowns and host totals survive restarts and redeploys.
Set the start command to `python events_bot.py` and enter `DISCORD_TOKEN` plus
the channel and role IDs in the service's private Variables page.

If the server has a custom emoji named `robux`, it is used in the post. Otherwise,
the bot uses `ROBUX_EMOJI` from `.env`.

## Tier settings copied from the supplied commands

| Command | Amount range | Default | Host cooldown | Discussion thread |
|---|---:|---:|---:|---|
| `-mini` | 5–25 | 5 | 6 minutes | — |
| `-starter` | 25–99 | 25 | 4 minutes | — |
| `-rising` | 100–499 | 100 | 12 minutes | 1 day |
| `-elite` | 500–999 | 500 | 12 minutes | 7 days |
| `-royal` | 1,000–4,999 | 1,000 | 12 minutes | 7 days |
| `-legendary` | 5,000–10,000 | 5,000 | 12 minutes | 7 days |
| `-ultimate` | 10,000–2,147,483,647 | 10,000 | 12 minutes | 7 days |

The Rising script initializes an `ascendant` statistic but increments `rising`;
this bot increments `rising` and keeps the `ascendant` field for compatibility.
