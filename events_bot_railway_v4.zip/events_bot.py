"""Standalone Discord bot for the seven supplied event-posting commands."""

from __future__ import annotations

import os
import sqlite3
import time
from contextlib import closing
from dataclasses import dataclass
from pathlib import Path

import discord
from discord.ext import commands
from dotenv import load_dotenv


load_dotenv(Path(__file__).with_name(".env"))
TOKEN = os.getenv("DISCORD_TOKEN", "").strip()
_data_dir = os.getenv("DATA_DIR", "").strip()
DATA_DIR = Path(_data_dir).expanduser() if _data_dir else Path(__file__).resolve().parent
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_DIR / "events.sqlite3"
ROBUX_EMOJI = os.getenv("ROBUX_EMOJI", "💰").strip() or "💰"


@dataclass(frozen=True)
class Tier:
    command: str
    title: str
    min_amount: int
    max_amount: int
    default_amount: int
    cooldown: int
    channel_env: str
    role_env: str
    channel_error: str
    cooldown_heading: str
    cooldown_event: str
    stat_key: str
    thread_name: str = ""
    thread_minutes: int = 0
    browse_channels: bool = False


TIERS = {
    "mini": Tier("mini", "Mini", 5, 25, 5, 360, "MINI_CHANNEL_ID", "MINI_ROLE_ID",
                 "Mini Events", "Mini Events", "Mini Event", "mini"),
    "starter": Tier("starter", "Starter", 25, 99, 25, 240, "STARTER_CHANNEL_ID", "STARTER_ROLE_ID",
                    "Starter Events", "Starter Events", "Starter Event", "starter"),
    "rising": Tier("rising", "Rising", 100, 499, 100, 720, "RISING_CHANNEL_ID", "RISING_ROLE_ID",
                   "Rising event", "Rising", "Rising event", "rising", "Rising Event Discussion", 1440),
    "elite": Tier("elite", "Elite", 500, 999, 500, 720, "ELITE_CHANNEL_ID", "ELITE_ROLE_ID",
                  "Elite event", "Elite", "Elite event", "elite", "Elite Event Discussion", 10080),
    "royal": Tier("royal", "Royal", 1000, 4999, 1000, 720, "ROYAL_CHANNEL_ID", "ROYAL_ROLE_ID",
                  "Royal event", "Royal", "Royal event", "royal", "Royal Event Discussion", 10080, True),
    "legendary": Tier("legendary", "Legendary", 5000, 10000, 5000, 720,
                      "LEGENDARY_CHANNEL_ID", "LEGENDARY_ROLE_ID", "Legendary event",
                      "Legendary", "Legendary event", "legendary", "Legendary Event Discussion", 10080),
    "ultimate": Tier("ultimate", "Ultimate", 10000, 2147483647, 10000, 720,
                     "ULTIMATE_CHANNEL_ID", "ULTIMATE_ROLE_ID", "Ultimate event",
                     "Ultimate", "Ultimate event", "ultimate", "Ultimate Event Discussion", 10080),
}

HOSTER_ROLE_IDS = {
    1564051750678171748,
    1551618568565555281,
    1551618999563845782,
    1551619943328653453,
    1551620689428086904,
    1551621171978444820,
    1551621366652870706,
}
HOST_RULES_CHANNEL_ID = 1541859515270570117


def read_id(name: str) -> int:
    value = os.getenv(name, "").strip()
    return int(value) if value.isdigit() else 0


def open_db() -> sqlite3.Connection:
    return sqlite3.connect(DB_PATH, timeout=10)


def init_db() -> None:
    with closing(open_db()) as db:
        with db:
            db.execute(
                """CREATE TABLE IF NOT EXISTS cooldowns (
                    tier TEXT NOT NULL, user_id INTEGER NOT NULL,
                    last INTEGER NOT NULL, duration INTEGER NOT NULL,
                    PRIMARY KEY (tier, user_id)
                )"""
            )
            db.execute(
                """CREATE TABLE IF NOT EXISTS host_stats (
                    user_id INTEGER PRIMARY KEY,
                    events INTEGER NOT NULL DEFAULT 0,
                    total INTEGER NOT NULL DEFAULT 0,
                    mini INTEGER NOT NULL DEFAULT 0,
                    starter INTEGER NOT NULL DEFAULT 0,
                    rising INTEGER NOT NULL DEFAULT 0,
                    ascendant INTEGER NOT NULL DEFAULT 0,
                    elite INTEGER NOT NULL DEFAULT 0,
                    royal INTEGER NOT NULL DEFAULT 0,
                    legendary INTEGER NOT NULL DEFAULT 0,
                    ultimate INTEGER NOT NULL DEFAULT 0,
                    last INTEGER NOT NULL DEFAULT 0
                )"""
            )
            db.execute(
                """CREATE TABLE IF NOT EXISTS host_blacklist (
                    guild_id INTEGER NOT NULL,
                    user_id INTEGER NOT NULL,
                    reason TEXT NOT NULL DEFAULT '',
                    added_by INTEGER NOT NULL,
                    added_at INTEGER NOT NULL,
                    PRIMARY KEY (guild_id, user_id)
                )"""
            )


def take_cooldown(tier: Tier, user_id: int, now: int) -> int:
    with closing(open_db()) as db:
        with db:
            row = db.execute(
                "SELECT last, duration FROM cooldowns WHERE tier = ? AND user_id = ?",
                (tier.command, user_id),
            ).fetchone()
            if row:
                remaining = int(row[1]) - (now - int(row[0]))
                if remaining > 0:
                    return remaining
            db.execute(
                """INSERT INTO cooldowns (tier, user_id, last, duration)
                   VALUES (?, ?, ?, ?)
                   ON CONFLICT(tier, user_id) DO UPDATE SET
                     last = excluded.last, duration = excluded.duration""",
                (tier.command, user_id, now, tier.cooldown),
            )
    return 0


def record_host(tier: Tier, user_id: int, amount: int, now: int) -> None:
    # stat_key is defined only in the fixed TIERS table above.
    column = tier.stat_key
    with closing(open_db()) as db:
        with db:
            db.execute("INSERT OR IGNORE INTO host_stats (user_id) VALUES (?)", (user_id,))
            db.execute(
                f"""UPDATE host_stats SET events = events + 1,
                    total = total + ?, {column} = {column} + 1, last = ?
                    WHERE user_id = ?""",
                (amount, now, user_id),
            )


def get_host_blacklist_entry(guild_id: int, user_id: int) -> tuple[str, int] | None:
    with closing(open_db()) as db:
        return db.execute(
            "SELECT reason, added_by FROM host_blacklist WHERE guild_id = ? AND user_id = ?",
            (guild_id, user_id),
        ).fetchone()


async def post_event(ctx: commands.Context, tier: Tier, amount: int) -> None:
    if not tier.min_amount <= amount <= tier.max_amount:
        await ctx.send(
            f"Usage: -{tier.command} [amount] "
            f"(amount must be {tier.min_amount}–{tier.max_amount})"
        )
        return
    if ctx.guild is None:
        await ctx.send("Use this command in a server channel.")
        return

    blacklist_entry = get_host_blacklist_entry(ctx.guild.id, ctx.author.id)
    if blacklist_entry is not None:
        reason = blacklist_entry[0] or "No reason provided."
        await ctx.send(f"❌ You are not allowed to host events. Reason: {reason}")
        return

    channel_id = read_id(tier.channel_env)
    role_id = read_id(tier.role_env)
    if not channel_id or not role_id:
        await ctx.send(
            f"{tier.title} is not configured yet. Set {tier.channel_env} and "
            f"{tier.role_env} in the .env file."
        )
        return
    if ctx.channel.id != channel_id:
        await ctx.send(f"❌ Use this command in the {tier.channel_error} channel.")
        return

    role = ctx.guild.get_role(role_id)
    if role is None:
        await ctx.send(f"The configured {tier.title} event role was not found in this server.")
        return

    now = int(time.time())
    remaining = take_cooldown(tier, ctx.author.id, now)
    if remaining > 0:
        minutes, seconds = divmod(remaining, 60)
        await ctx.send(
            f"⏳ **{tier.cooldown_heading} cooldown active!**\n\n"
            f"Please wait **{minutes}m {seconds}s** before hosting another "
            f"{tier.cooldown_event}."
        )
        return

    robux = discord.utils.get(ctx.guild.emojis, name="robux") or ROBUX_EMOJI
    ping_help = "Want to **change your pings?** Edit them in --> "
    if tier.browse_channels:
        ping_help += "**Browse Channels & Roles** "
    ping_help += "<id:customize>"
    content = (
        f"**{ctx.author.mention} is starting a {tier.title} Event!** "
        f"**({amount} {robux})**\n\n{role.mention}\n\n{ping_help}"
    )
    allowed_mentions = discord.AllowedMentions(
        users=[ctx.author], roles=[role], everyone=False, replied_user=False
    )
    try:
        posted = await ctx.send(content, allowed_mentions=allowed_mentions)
    except discord.Forbidden:
        return

    record_host(tier, ctx.author.id, amount, now)

    if tier.thread_name:
        try:
            await posted.create_thread(
                name=tier.thread_name,
                auto_archive_duration=tier.thread_minutes,
            )
        except discord.Forbidden:
            print(f"Missing permission to create the {tier.title} discussion thread.")
        except discord.HTTPException as error:
            print(f"Could not create the {tier.title} discussion thread: {error}")

    try:
        await posted.add_reaction("👍")
        await posted.add_reaction("👎")
    except discord.Forbidden:
        print(f"Missing permission to add reactions to the {tier.title} event post.")


intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="-", intents=intents)


@bot.command(name="mini")
async def mini(ctx: commands.Context, amount: int = 5) -> None:
    await post_event(ctx, TIERS["mini"], amount)


@bot.command(name="starter")
async def starter(ctx: commands.Context, amount: int = 25) -> None:
    await post_event(ctx, TIERS["starter"], amount)


@bot.command(name="rising")
async def rising(ctx: commands.Context, amount: int = 100) -> None:
    await post_event(ctx, TIERS["rising"], amount)


@bot.command(name="elite")
async def elite(ctx: commands.Context, amount: int = 500) -> None:
    await post_event(ctx, TIERS["elite"], amount)


@bot.command(name="royal")
async def royal(ctx: commands.Context, amount: int = 1000) -> None:
    await post_event(ctx, TIERS["royal"], amount)


@bot.command(name="legendary")
async def legendary(ctx: commands.Context, amount: int = 5000) -> None:
    await post_event(ctx, TIERS["legendary"], amount)


@bot.command(name="ultimate")
async def ultimate(ctx: commands.Context, amount: int = 10000) -> None:
    await post_event(ctx, TIERS["ultimate"], amount)


@bot.command(name="gw")
async def hosting_giveaway(ctx: commands.Context, amount: int | None = None) -> None:
    """Post a hosting-giveaway announcement in the channel where -gw is used."""
    if ctx.guild is None:
        await ctx.send("Use this command in a server channel.")
        return
    if amount is not None and amount <= 0:
        await ctx.send("Usage: -gw [positive Robux amount]")
        return

    blacklist_entry = get_host_blacklist_entry(ctx.guild.id, ctx.author.id)
    if blacklist_entry is not None:
        reason = blacklist_entry[0] or "No reason provided."
        await ctx.send(f"❌ You are not allowed to host giveaways. Reason: {reason}")
        return

    role_id = read_id("GIVEAWAY_PING_ROLE_ID")
    if not role_id:
        await ctx.send(
            "Giveaway ping role is not configured. Set GIVEAWAY_PING_ROLE_ID in the .env file."
        )
        return
    role = ctx.guild.get_role(role_id)
    if role is None:
        await ctx.send("The configured giveaway ping role was not found in this server.")
        return

    robux = discord.utils.get(ctx.guild.emojis, name="robux") or ROBUX_EMOJI
    prize = f" **({amount} {robux})**" if amount is not None else ""
    content = (
        f"**{ctx.author.mention} is starting a Hosting Giveaway!**{prize}\n\n"
        f"{role.mention}\n\n"
        "Want to **change your pings?** Edit them in --> <id:customize>"
    )
    allowed_mentions = discord.AllowedMentions(
        users=[ctx.author], roles=[role], everyone=False, replied_user=False
    )
    try:
        posted = await ctx.send(content, allowed_mentions=allowed_mentions)
    except discord.Forbidden:
        return

    try:
        await posted.add_reaction("👍")
        await posted.add_reaction("👎")
    except discord.Forbidden:
        print("Missing permission to add reactions to the hosting giveaway post.")


@bot.command(name="gh")
async def give_hoster_role(
    ctx: commands.Context, target: discord.Member, role: discord.Role
) -> None:
    if ctx.guild is None:
        await ctx.send("Use this command in the server.")
        return
    if not ctx.author.guild_permissions.administrator:
        await ctx.send("❌ You need Administrator permission to use this command.")
        return
    if role.id not in HOSTER_ROLE_IDS:
        await ctx.send("❌ Please mention a Hoster role.")
        return

    try:
        await target.add_roles(role, reason=f"Hoster role granted by {ctx.author} via -gh")
    except discord.Forbidden:
        await ctx.send(
            "❌ I couldn't grant that role. Make sure I have Manage Roles permission "
            "and my highest role is above the Hoster role."
        )
        return

    await ctx.send(
        "✅ Hoster role granted! Make sure to read the host rules in "
        f"<#{HOST_RULES_CHANNEL_ID}>."
    )


def is_admin(ctx: commands.Context) -> bool:
    return ctx.guild is not None and ctx.author.guild_permissions.administrator


@bot.command(name="hostblacklist", aliases=["blacklist", "hbl"])
async def host_blacklist(
    ctx: commands.Context, member: discord.Member, *, reason: str = "No reason provided."
) -> None:
    if not is_admin(ctx):
        await ctx.send("❌ You need Administrator permission to use this command.")
        return
    with closing(open_db()) as db:
        with db:
            db.execute(
                """INSERT INTO host_blacklist (guild_id, user_id, reason, added_by, added_at)
                   VALUES (?, ?, ?, ?, ?)
                   ON CONFLICT(guild_id, user_id) DO UPDATE SET
                     reason = excluded.reason,
                     added_by = excluded.added_by,
                     added_at = excluded.added_at""",
                (ctx.guild.id, member.id, reason, ctx.author.id, int(time.time())),
            )
    await ctx.send(
        f"✅ {member.mention} is now blacklisted from hosting. Reason: {reason}",
        allowed_mentions=discord.AllowedMentions.none(),
    )


@bot.command(name="hostunblacklist", aliases=["unblacklist", "uhbl"])
async def host_unblacklist(ctx: commands.Context, member: discord.Member) -> None:
    if not is_admin(ctx):
        await ctx.send("❌ You need Administrator permission to use this command.")
        return
    with closing(open_db()) as db:
        with db:
            result = db.execute(
                "DELETE FROM host_blacklist WHERE guild_id = ? AND user_id = ?",
                (ctx.guild.id, member.id),
            )
    if result.rowcount == 0:
        await ctx.send("That user is not on the host blacklist.")
        return
    await ctx.send(
        f"✅ {member.mention} can host events again.",
        allowed_mentions=discord.AllowedMentions.none(),
    )


@bot.command(name="hostblacklistlist", aliases=["blacklistlist", "hblist"])
async def host_blacklist_list(ctx: commands.Context) -> None:
    if not is_admin(ctx):
        await ctx.send("❌ You need Administrator permission to use this command.")
        return
    with closing(open_db()) as db:
        rows = db.execute(
            """SELECT user_id, reason FROM host_blacklist
               WHERE guild_id = ? ORDER BY added_at DESC LIMIT 12""",
            (ctx.guild.id,),
        ).fetchall()
    if not rows:
        await ctx.send("The host blacklist is empty.")
        return
    lines = [
        f"<@{user_id}> — {(reason or 'No reason provided.')[:120]}"
        for user_id, reason in rows
    ]
    await ctx.send(
        "**Host blacklist**\n" + "\n".join(lines),
        allowed_mentions=discord.AllowedMentions.none(),
    )


@bot.command(name="hoststats", aliases=["mystats"])
async def host_stats(ctx: commands.Context, member: discord.Member | None = None) -> None:
    if ctx.guild is None:
        await ctx.send("Use this command in a server.")
        return
    target = member or ctx.author
    with closing(open_db()) as db:
        row = db.execute(
            """SELECT events, total, mini, starter, rising, elite, royal,
                      legendary, ultimate, last
               FROM host_stats WHERE user_id = ?""",
            (target.id,),
        ).fetchone()
    if row is None:
        await ctx.send(f"{target.display_name} has not hosted an event yet.")
        return
    events, total, mini_count, starter_count, rising_count, elite_count, royal_count, legendary_count, ultimate_count, last = row
    last_text = f"<t:{last}:R>" if last else "Never"
    await ctx.send(
        f"**Host stats for {target.mention}**\n"
        f"Events: **{events}** · Total: **{total:,} {ROBUX_EMOJI}**\n"
        f"Mini: {mini_count} · Starter: {starter_count} · Rising: {rising_count}\n"
        f"Elite: {elite_count} · Royal: {royal_count} · Legendary: {legendary_count} · Ultimate: {ultimate_count}\n"
        f"Last hosted: {last_text}",
        allowed_mentions=discord.AllowedMentions.none(),
    )


@bot.command(name="leaderboard", aliases=["hostleaderboard", "tophosts", "hosttop"])
async def host_leaderboard(ctx: commands.Context, sort_by: str = "events") -> None:
    metric = sort_by.lower()
    if metric in {"amount", "total", "robux"}:
        ordering = "total DESC, events DESC, last ASC, user_id ASC"
        heading = "Robux hosted"
    elif metric in {"events", "count"}:
        ordering = "events DESC, total DESC, last ASC, user_id ASC"
        heading = "Events hosted"
    else:
        await ctx.send("Usage: -leaderboard [events|amount]")
        return
    with closing(open_db()) as db:
        rows = db.execute(
            f"""SELECT user_id, events, total FROM host_stats
                WHERE events > 0 ORDER BY {ordering} LIMIT 10"""
        ).fetchall()
    if not rows:
        await ctx.send("No hosted events have been recorded yet.")
        return
    if heading == "Events hosted":
        lines = [
            f"**{rank}.** <@{user_id}> — {events} events · {total:,} {ROBUX_EMOJI}"
            for rank, (user_id, events, total) in enumerate(rows, start=1)
        ]
    else:
        lines = [
            f"**{rank}.** <@{user_id}> — {total:,} {ROBUX_EMOJI} · {events} events"
            for rank, (user_id, events, total) in enumerate(rows, start=1)
        ]
    await ctx.send(
        f"🏆 **Hosted leaderboard · {heading}**\n" + "\n".join(lines),
        allowed_mentions=discord.AllowedMentions.none(),
    )


@bot.event
async def on_command_error(ctx: commands.Context, error: commands.CommandError) -> None:
    error = getattr(error, "original", error)
    invoked = (ctx.invoked_with or "").lower()
    if isinstance(error, commands.MemberNotFound) and invoked == "gh":
        await ctx.send("❌ User not found in this server.")
        return
    if isinstance(error, commands.RoleNotFound) and invoked == "gh":
        await ctx.send("❌ Please mention a Hoster role.")
        return
    if isinstance(error, commands.MemberNotFound) and invoked in {
        "hostblacklist", "blacklist", "hbl", "hostunblacklist", "unblacklist", "uhbl"
    }:
        await ctx.send("❌ User not found in this server.")
        return
    if isinstance(error, (commands.BadArgument, commands.MissingRequiredArgument,
                          commands.TooManyArguments)):
        if invoked == "gw":
            await ctx.send("Usage: -gw [positive Robux amount]")
            return
        if invoked in {"gh", "hostblacklist", "blacklist", "hbl",
                       "hostunblacklist", "unblacklist", "uhbl"}:
            usage = {
                "gh": "Usage: -gh @user @hoster-role",
                "hostblacklist": "Usage: -hostblacklist @user [reason]",
                "blacklist": "Usage: -hostblacklist @user [reason]",
                "hbl": "Usage: -hostblacklist @user [reason]",
                "hostunblacklist": "Usage: -hostunblacklist @user",
                "unblacklist": "Usage: -hostunblacklist @user",
                "uhbl": "Usage: -hostunblacklist @user",
            }
            await ctx.send(usage[invoked])
            return
        tier = TIERS.get(invoked)
        if tier:
            await ctx.send(
                f"Usage: -{tier.command} [amount] "
                f"(amount must be {tier.min_amount}–{tier.max_amount})"
            )
        return
    if isinstance(error, commands.CommandNotFound):
        return
    print(f"Command error: {error}")


@bot.event
async def on_ready() -> None:
    print(f"Ready as {bot.user} ({bot.user.id})")


if __name__ == "__main__":
    if not TOKEN:
        raise SystemExit("Set DISCORD_TOKEN in the .env file before starting the bot.")
    init_db()
    bot.run(TOKEN)
